'''
Assignment 2
Name: 黃君翰
Student Number: 109502566
Course 2020-CE1001
'''
str = input("Input String:")
print("a:",str.count('a'),",e:",str.count('e'),",i:",str.count('i'),",o:",str.count('o'),",u:",str.count('u'))
