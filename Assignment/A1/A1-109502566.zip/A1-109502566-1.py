'''
Assignment 1
Name: 黃君翰
Student Number: 109502566
Course 2020-CE1001
'''

str1 = input("input1:")
str2 = input("input2:")
str3 = input("input3:")

print(str3, str2, str1, sep=" ")
