'''
Assignment 1
Name: 黃君翰
Student Number: 109502566
Course 2020-CE1001
'''

str1 = input()
str2 = input()

x, y = int(str1), int(str2)

sum_int = x + y
dif_int = x - y
pro_int = x * y
quo_float = float(x) / y
pow_int = x ** y
quo_int = x // y
rem_int = x % y

print(sum_int, dif_int, pro_int, quo_float, pow_int, quo_int, rem_int, sep="\n")


