'''
Practice 1
Name: 黃君翰
Student Number: 109502566
Course 2020-CE1003-B
'''


str = input()
print("hello world", str)

