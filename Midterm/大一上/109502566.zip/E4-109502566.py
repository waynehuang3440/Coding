file = open('text.txt','r')

line = file.readline()
split = line.split()

operation_small = []
operation_big = []
n = 0
len = len(split[0])
print(len)

while n < len:
    if line[n] == '(' or line[n] == ')':
        n = n + 1
        
    else:
        flag = 0
        for m in range(n,len):
            if line[m] == '(' or line[m] == ')':
                break
            operation_small.append(line[m])
            flag += 1
        operation_small_str = "".join(operation_small)
        if operation_small_str != '':
            operation_big.append("".join(operation_small))
        operation_small = []
        n = n + flag
    
print(operation_big)


file.close()
